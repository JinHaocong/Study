/*
 * @Author: Jin Haocong
 * @Date: 2022-09-15 21:10:58
 * @LastEditTime: 2022-09-15 22:56:54
 */
import { Button, Popover, Table, Tag, Modal } from "antd";
import {
  DeleteOutlined,
  ExclamationCircleOutlined,
  UserOutlined,
  AppstoreOutlined,
  GlobalOutlined,
  ArrowDownOutlined,
} from "@ant-design/icons";
import React from "react";
import { NavLink } from "react-router-dom";
const { confirm } = Modal;

export default function NewsPublish(props) {
  const showConfirm = (item) => {
    confirm({
      title: "确定要删除吗?",
      icon: <ExclamationCircleOutlined />,
      content: "该操作不可撤销",

      onOk() {
        // handleDelete(item);
        props.handleDelete(item);
      },

      onCancel() {},
    });
  };

  const columns = [
    {
      title: "ID",
      dataIndex: "id",
      align: "center",
      key: "id",
      render: (id) => {
        return <b>{id}</b>;
      },
    },
    {
      title: "新闻标题",
      align: "center",
      dataIndex: "title",
      key: "title",
      render: (title, item) => {
        return (
          <NavLink to={`/news-manage/preview/${item.id}`}>{title}</NavLink>
        );
      },
    },
    {
      title: "作者",
      align: "center",
      dataIndex: "author",
      key: "address",
      render: (author) => {
        return (
          <Tag
            color="purple"
            icon={<UserOutlined />}
            style={{ fontSize: "15px" }}
          >
            {author}
          </Tag>
        );
      },
    },
    {
      title: "新闻分类",
      align: "center",
      dataIndex: "category",
      key: "category",
      render: (category) => {
        return (
          <Tag
            icon={<AppstoreOutlined />}
            color="geekblue"
            style={{ fontSize: "15px" }}
          >
            {category.title}
          </Tag>
        );
      },
    },
    {
      title: "操作",
      align: "center",
      render: (item) => {
        return (
          <div>
            {props.buttonType === 2 && (
              <Popover content="下线" trigger="hover" placement="bottom">
                <Button
                  size="large"
                  shape="circle"
                  icon={<ArrowDownOutlined />}
                  type="primary"
                  style={{
                    margin: "0 10px",
                    background: "orange",
                    border: "0",
                  }}
                  onClick={() => {
                    props.handleSunSet(item);
                  }}
                ></Button>
              </Popover>
            )}
            {props.buttonType === 1 && (
              <Popover content="发布" trigger="hover" placement="bottom">
                <Button
                  type="primary"
                  shape="circle"
                  size="large"
                  icon={<GlobalOutlined />}
                  style={{ background: "#00FF00", border: "0" }}
                  onClick={() => {
                    props.handlePublish(item);
                  }}
                ></Button>
              </Popover>
            )}
            {props.buttonType === 3 && (
              <div>
                <Popover content="删除" trigger="hover" placement="bottom">
                  <Button
                    size="large"
                    shape="circle"
                    icon={<DeleteOutlined />}
                    danger
                    style={{ margin: "0 10px" }}
                    onClick={() => {
                      showConfirm(item);
                    }}
                  ></Button>
                </Popover>
                <Popover content="发布" trigger="hover" placement="bottom">
                  <Button
                    type="primary"
                    shape="circle"
                    size="large"
                    icon={<GlobalOutlined />}
                    style={{ background: "#00FF00", border: "0" }}
                    onClick={() => {
                      props.handlePublish(item);
                    }}
                  ></Button>
                </Popover>
              </div>
            )}
          </div>
        );
      },
    },
  ];
  return (
    <div>
      <Table
        dataSource={props.newsList}
        columns={columns}
        pagination={{ pageSize: "10" }}
        rowKey={(item) => item.id}
      />
    </div>
  );
}
