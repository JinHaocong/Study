/*
 * @Author: Jin Haocong
 * @Date: 2022-09-13 12:36:16
 * @LastEditTime: 2022-09-14 00:14:05
 */
import React, { forwardRef, useState, useEffect } from "react";
import { Input, Form, Select } from "antd";
import { EyeTwoTone, EyeInvisibleOutlined } from "@ant-design/icons";
const { Option } = Select;

function Userform(props, ref) {
  const [isDisalbed, setisDisalbed] = useState(false);
  const { roleId, region } = JSON.parse(localStorage.getItem("token"));

  const roleMap = {
    1: "superadmin",
    2: "admin",
    3: "editor",
  };

  const isSelectDisalbed = () => {
    if (props.formType === "update") {
      if (roleMap[roleId] === "superadmin") {
        return false;
      } else {
        return true;
      }
    }
  };

  const isOptionDisabled = (item) => {
    if (roleMap[roleId] === "superadmin") {
      return false;
    } else {
      return item.value !== region;
    }
  };

  const checkRoleDisabled = (item) => {
    if (roleMap[roleId] === "superadmin") {
      return false;
    } else {
      return roleMap[item.id] !== "editor";
    }
  };
  useEffect(() => {
    setisDisalbed(props.isUpdateDisabled);
  }, [props.isUpdateDisabled]);

  return (
    <Form ref={ref} layout="vertical">
      <Form.Item
        name="username"
        label="用户名"
        rules={[
          {
            required: true,
            message: "用户名不能为空!",
          },
        ]}
      >
        <Input placeholder="请输入用户名" />
      </Form.Item>
      <Form.Item
        name="password"
        label="密码"
        rules={[
          {
            required: true,
            message: "密码不能为空!",
          },
        ]}
      >
        <Input.Password
          placeholder="请输入密码"
          iconRender={(visible) =>
            visible ? <EyeTwoTone /> : <EyeInvisibleOutlined />
          }
        />
      </Form.Item>
      <Form.Item
        name="region"
        label="区域"
        rules={
          isDisalbed
            ? []
            : [
                {
                  required: true,
                  message: "角色不能为空!",
                },
              ]
        }
      >
        <Select
          showSearch
          disabled={isDisalbed || isSelectDisalbed()}
          placeholder="请选择区域"
          optionFilterProp="children"
          allowClear
          // onChange={onChange}
          // onSearch={onSearch}
          filterOption={(input, option) =>
            option.children.toLowerCase().includes(input.toLowerCase())
          }
        >
          {props.regionList.map((item) => (
            <Option
              value={item.value}
              key={item.id}
              disabled={isOptionDisabled(item)}
            >
              {item.title}
            </Option>
          ))}
        </Select>
      </Form.Item>
      <Form.Item
        name="roleId"
        label="角色"
        rules={[
          {
            required: true,
            message: "角色不能为空!",
          },
        ]}
      >
        <Select
          showSearch
          placeholder="请选择角色"
          disabled={isSelectDisalbed()}
          optionFilterProp="children"
          onChange={(value) => {
            if (value === 1) {
              ref.current.setFieldsValue({
                region: "",
              });
              setisDisalbed(true);
            } else {
              setisDisalbed(false);
            }
          }}
          // onSearch={onSearch}
          filterOption={(input, option) =>
            option.children.toLowerCase().includes(input.toLowerCase())
          }
        >
          {props.roleList.map((item) => (
            <Option
              value={item.id}
              key={item.id}
              disabled={checkRoleDisabled(item)}
            >
              {item.roleName}
            </Option>
          ))}
        </Select>
      </Form.Item>
    </Form>
  );
}

export default forwardRef(Userform);
