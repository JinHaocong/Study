import {
  Button,
  Form,
  Input,
  message,
  PageHeader,
  Select,
  Steps,
  notification,
} from "antd";
import React, { useState, useEffect, useRef } from "react";
import { useNavigate, useParams } from "react-router-dom";
import NewsEditor from "../../../components/news-manage/NewsEditor";
import Request from "../../../request";
import style from "./News.module.css";
const { Option } = Select;
const { Step } = Steps;

export default function NewsUpdate() {
  const [current, setCurrent] = useState(0);
  const [categroyList, setCategroyList] = useState([]);
  const formRef = useRef(null);
  const [formInfo, setFormInfo] = useState({});
  const [content, setContent] = useState("");
  const navigate = useNavigate();
  const params = useParams();
  const user = JSON.parse(localStorage.getItem("token"));
  const handleNext = () => {
    if (current === 0) {
      formRef.current
        .validateFields()
        .then((res) => {
          setFormInfo(res);
          setCurrent(current + 1);
        })
        .catch((err) => {});
    } else {
      if (content === "" || content.trim() === "<p></p>") {
        message.error("新闻内容不能为空");
      } else {
        setCurrent(current + 1);
      }
    }
  };

  const handlePrevious = () => {
    setCurrent(current - 1);
  };

  const handleSave = (auditState) => {
    Request({
      method: "patch",
      url: `/news/${params.id}`,
      data: {
        ...formInfo,
        content: content,
        region: user.region ? user.region : "全球",
        author: user.username,
        roleId: user.roleId,
        auditState: auditState,
        publishState: 0,
        createTime: Date.now(),
        star: 0,
        view: 0,
        // publishTime: 0,
      },
    }).then(() => {
      message.success(auditState ? "推送成功" : "更新");
      navigate(auditState === 0 ? "/news-manage/draft" : "/audit-manage/list");
      notification.info({
        message: "更新成功",
        description: `您可以到${
          auditState === 0 ? "草稿箱" : "审核列表中"
        }查看新闻`,
        placement: "bottomRight",
      });
    });
  };

  useEffect(() => {
    Request({
      method: "get",
      url: "/categories",
    }).then((res) => {
      setCategroyList(res);
    });
  }, []);

  useEffect(() => {
    Request({
      method: "get",
      url: `/news/${params.id}?_expand=category&_expand=role`,
    }).then((res) => {
      const { title, categoryId, content } = res;
      formRef.current.setFieldsValue({
        title,
        categoryId,
      });
      setContent(content);
    });
  }, [params]);

  return (
    <div>
      <PageHeader
        className="site-page-header"
        title="更新新闻"
        subTitle="新闻更新"
        onBack={() => navigate("/news-manage/draft")}
      />

      <Steps current={current}>
        <Step title="基本信息" description="新闻标题，新闻分类" />
        <Step title="新闻内容" description="新闻主题内容" />
        <Step title="新闻提交" description="保存草稿或提交审核" />
      </Steps>

      <div
        style={{
          margin: "50px",
        }}
      >
        <div className={current === 0 ? "" : style.hidden}>
          <Form
            name="basic"
            ref={formRef}
            labelCol={{
              span: 4,
            }}
            wrapperCol={{
              span: 20,
            }}
            initialValues={{
              remember: true,
            }}
            autoComplete="off"
          >
            <Form.Item
              label="新闻标题"
              name="title"
              rules={[
                {
                  required: true,
                  message: "新闻标题不能为空！",
                },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              label="新闻分类"
              name="categoryId"
              rules={[
                {
                  required: true,
                  message: "新闻分类不能为空！",
                },
              ]}
            >
              <Select allowClear>
                {categroyList.map((item) => (
                  <Option key={item.id} value={item.id}>
                    {item.title}
                  </Option>
                ))}
              </Select>
            </Form.Item>
          </Form>
        </div>
        <div className={current === 1 ? "" : style.hidden}>
          <NewsEditor
            getContent={(value) => {
              setContent(value);
            }}
            content={content}
          ></NewsEditor>
        </div>
        <div className={current === 2 ? "" : style.hidden}></div>
      </div>
      <div className={style.buttonbox}>
        {current > 0 && (
          <Button
            shape="round"
            style={{ margin: "0 10px" }}
            onClick={() => {
              handlePrevious();
            }}
          >
            上一步
          </Button>
        )}
        {current < 2 && (
          <Button
            type="primary"
            shape="round"
            style={{ margin: "0 10px" }}
            onClick={() => {
              handleNext();
            }}
          >
            下一步
          </Button>
        )}

        {current === 2 && (
          <span>
            <Button
              type="primary"
              shape="round"
              style={{ margin: "0 10px" }}
              onClick={() => {
                handleSave(0);
              }}
            >
              保存草稿箱
            </Button>
            <Button
              shape="round"
              type="primary"
              style={{ margin: "0 10px", background: "#00a000", border: "0" }}
              onClick={() => {
                handleSave(1);
              }}
            >
              提交审核
            </Button>
          </span>
        )}
      </div>
    </div>
  );
}
