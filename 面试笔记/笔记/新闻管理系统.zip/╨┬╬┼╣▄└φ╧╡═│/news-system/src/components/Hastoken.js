/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 15:02:21
 * @LastEditTime: 2022-09-11 15:04:39
 */
import React from "react";
import Redirect from "./Redirect";

export default function Hastoken(props) {
  const token = localStorage.getItem("token");
  return token ? (
    <div>{props.children} </div>
  ) : (
    <Redirect to="/login"></Redirect>
  );
}
