import React, { useState, useEffect, useImperativeHandle } from "react";
import { Button, Table, Tag, Modal, Popover, Switch, message } from "antd";
import {
  RocketOutlined,
  DeleteOutlined,
  EditOutlined,
  ExclamationCircleOutlined,
} from "@ant-design/icons";
import Request from "../../../request";
const { confirm } = Modal;

export default function RightList(props) {
  const [dataSource, setDataSource] = useState([]);
  useEffect(() => {
    getDataList();
  }, []);
  props.getData();
  const getDataList = () => {
    Request({
      url: "/rights?_embed=children",
      method: "get",
    }).then((res) => {
      const list = res;
      list.forEach((item) => {
        if (item.children && item.children.length === 0) {
          delete item.children;
        }
      });
      setDataSource(list);
    });
  };

  useImperativeHandle(
    props.ref,
    () => {
      return {
        getFunc: getDataList,
      };
    },
    []
  );

  const columns = [
    {
      title: "ID",
      dataIndex: "id",
      align: "center",
      key: "id",
      render: (id) => {
        return <b>{id}</b>;
      },
    },
    {
      title: "权限名称",
      align: "center",
      dataIndex: "label",
      key: "label",
    },
    {
      title: "权限路径",
      align: "center",
      dataIndex: "key",
      key: "key",
      render: (address) => {
        return (
          <Tag icon={<RocketOutlined />} color="processing">
            {address}
          </Tag>
        );
      },
    },
    {
      title: "操作",
      align: "center",
      render: (item) => {
        return (
          <div>
            <Popover content="删除" trigger="hover" placement="bottom">
              <Button
                size="large"
                shape="circle"
                icon={<DeleteOutlined />}
                danger
                style={{ margin: "0 10px" }}
                onClick={() => {
                  showConfirm(item);
                }}
              />
            </Popover>
            <Popover
              content={
                <div style={{ textAlign: "center" }}>
                  <Switch
                    checkedChildren="开启"
                    unCheckedChildren="关闭"
                    checked={item.pagepermisson}
                    onChange={() => {
                      switchMethod(item);
                    }}
                  />
                </div>
              }
              trigger={item.pagepermisson === undefined ? "" : "hover"}
              title="切换状态"
              placement="bottom"
            >
              <Button
                shape="circle"
                icon={<EditOutlined />}
                type="primary"
                size="large"
                style={{ margin: "0 10px" }}
                disabled={item.pagepermisson === undefined}
              />
            </Popover>
          </div>
        );
      },
    },
  ];

  const showConfirm = (item) => {
    confirm({
      title: "确定要删除吗?",
      icon: <ExclamationCircleOutlined />,
      content: "该操作不可撤销",

      onOk() {
        deleteMethod(item);
      },

      onCancel() {},
    });
  };

  const deleteMethod = (item) => {
    if (item.grade === 1) {
      Request({
        url: `/rights/${item.id}`,
        method: "delete",
      })
        .then(() => {
          getDataList();
          props.getData();
          message.success("删除成功");
        })
        .catch(() => {
          message.error("删除失败");
        });
    } else {
      Request({
        url: `/children/${item.id}`,
        method: "delete",
      })
        .then(() => {
          getDataList();
          props.getData();
          message.success("删除成功");
        })
        .catch(() => {
          message.error("删除失败");
        });
    }
  };

  const switchMethod = (item) => {
    item.pagepermisson = Number(!item.pagepermisson);
    if (item.grade === 1) {
      Request({
        url: `/rights/${item.id}`,
        method: "patch",
        data: {
          pagepermisson: item.pagepermisson,
        },
      })
        .then(() => {
          getDataList();
          props.getData();
          message.success("切换成功");
        })
        .catch(() => {
          message.error("切换失败");
        });
    } else {
      Request({
        url: `/children/${item.id}`,
        method: "patch",
        data: {
          pagepermisson: item.pagepermisson,
        },
      })
        .then(() => {
          getDataList();
          props.getData();
          message.success("更新成功");
        })
        .catch(() => {
          message.error("切换失败");
        });
    }
  };

  return (
    <div>
      <Table
        dataSource={dataSource}
        columns={columns}
        pagination={{ pageSize: "10" }}
      />
    </div>
  );
}
