/*
 * @Author: Jin Haocong
 * @Date: 2022-09-15 21:25:55
 * @LastEditTime: 2022-09-15 23:06:04
 */

import { message } from "antd";
import { useCallback, useEffect, useState } from "react";
import Request from "../../request";

export default function useGetNewsList(type) {
  const { username } = JSON.parse(localStorage.getItem("token"));
  const [newsList, setNewsList] = useState([]);

  const handleDelete = (item) => {
    Request({
      method: "delete",
      url: `/news/${item.id}`,
    }).then(() => {
      message.success("删除成功");
      getNewsList(type);
    });
  };

  const handlePublish = (item) => {
    Request({
      method: "patch",
      url: `/news/${item.id}`,
      data: {
        publishState: 2,
        publishTime: Date.now(),
      },
    }).then(() => {
      message.success("发布成功");
      getNewsList(type);
    });
  };

  const handleSunSet = (item) => {
    Request({
      method: "patch",
      url: `/news/${item.id}`,
      data: {
        publishState: 3,
      },
    }).then(() => {
      message.success("下线成功");
      getNewsList(type);
    });
  };

  const getNewsList = useCallback(() => {
    Request({
      method: "get",
      url: `/news?author=${username}&publishState=${type}&_expand=category`,
    }).then((res) => {
      setNewsList(res);
    });
  }, [type, username]);

  useEffect(() => {
    getNewsList();
  }, [getNewsList]);
  return {
    newsList,
    handleDelete,
    handlePublish,
    handleSunSet,
  };
}
