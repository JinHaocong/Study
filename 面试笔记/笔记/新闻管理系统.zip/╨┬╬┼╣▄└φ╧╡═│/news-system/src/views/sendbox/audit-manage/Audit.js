/*
 * @Author: Jin Haocong
 * @Date: 2022-09-14 02:04:19
 * @LastEditTime: 2022-09-15 14:05:38
 */
import { Button, message, notification, Popover, Table, Tag } from "antd";
import {
  UserOutlined,
  CloseOutlined,
  CheckOutlined,
  AppstoreOutlined,
} from "@ant-design/icons";
import React, { useCallback, useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import Request from "../../../request/index";

export default function Audit() {
  const [auditList, setAuditList] = useState([]);
  const { roleId, region, username } = JSON.parse(
    localStorage.getItem("token")
  );

  const getAuditList = useCallback(() => {
    const roleMap = {
      1: "superadmin",
      2: "admin",
      3: "editor",
    };
    Request({
      method: "get",
      url: "/news?auditState=1&_expand=category",
    }).then((res) => {
      setAuditList(
        roleMap[roleId] === "superadmin"
          ? res
          : [
              ...res.filter((item) => item.author === username),
              ...res.filter(
                (item) =>
                  item.region === region && roleMap[item.roleId] === "editor"
              ),
            ]
      );
    });
  }, [roleId, region, username]);

  const handleAudit = (item, auditState, publishState) => {
    Request({
      method: "patch",
      url: `/news/${item.id}`,
      data: {
        auditState,
        publishState,
      },
    }).then(() => {
      getAuditList();
      message.success("操作成功");
      notification.info({
        message: "通知",
        description: "您可以到【审核管理/审核列表】中查看新闻的审核状态",
        placement: "bottomRight",
      });
    });
  };

  const columns = [
    {
      title: "新闻标题",
      dataIndex: "title",
      key: "title",
      align: "center",
      render: (title, item) => (
        <NavLink to={`/news-manage/preview/${item.id}`}>{title}</NavLink>
      ),
    },
    {
      title: "作者",
      dataIndex: "author",
      key: "author",
      align: "center",
      render: (author) => {
        return (
          <Tag
            color="purple"
            icon={<UserOutlined />}
            style={{ fontSize: "15px" }}
          >
            {author}
          </Tag>
        );
      },
    },
    {
      title: "新闻分类",
      dataIndex: "category",
      key: "category",
      align: "center",
      render: (category) => (
        <Tag
          icon={<AppstoreOutlined />}
          color="geekblue"
          style={{ fontSize: "15px" }}
        >
          {category.title}
        </Tag>
      ),
    },
    {
      title: "操作",
      key: "title",
      align: "center",
      render: (item) => (
        <div>
          <Popover content="通过" trigger="hover" placement="bottom">
            <Button
              type="primary"
              shape="circle"
              size="large"
              style={{ margin: "0 10px" }}
              icon={<CheckOutlined />}
              onClick={() => {
                handleAudit(item, 2, 1);
              }}
            ></Button>
          </Popover>

          <Popover content="驳回" trigger="hover" placement="bottom">
            <Button
              type="primary"
              shape="circle"
              size="large"
              danger
              icon={<CloseOutlined />}
              style={{ margin: "0 10px" }}
              onClick={() => {
                handleAudit(item, 3, 0);
              }}
            ></Button>
          </Popover>
        </div>
      ),
    },
  ];

  useEffect(() => {
    getAuditList();
  }, [getAuditList]);

  return (
    <Table
      columns={columns}
      dataSource={auditList}
      rowKey={(item) => item.id}
      pagination={{
        pageSize: "5",
      }}
    />
  );
}
