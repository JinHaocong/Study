/*
 * @Author: Jin Haocong
 * @Date: 2022-09-14 02:05:08
 * @LastEditTime: 2022-09-15 22:55:08
 */
import React from "react";
import useGetNewsList from "../../../components/publish-manage/getNewsList";
import NewsPublish from "../../../components/publish-manage/NewsPublish";

export default function Published() {
  const { newsList, handleSunSet } = useGetNewsList(2);
  return (
    <div>
      <NewsPublish
        newsList={newsList}
        buttonType={2}
        handleSunSet={(item) => {
          handleSunSet(item);
        }}
      ></NewsPublish>
    </div>
  );
}
