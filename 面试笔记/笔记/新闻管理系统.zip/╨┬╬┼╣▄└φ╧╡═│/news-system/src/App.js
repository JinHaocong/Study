/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 14:00:31
 * @LastEditTime: 2022-09-16 09:01:20
 */

import { BrowserRouter } from "react-router-dom";
import Myrouter from "./router";
import { Provider } from "react-redux";
import { store, persistore } from "./redux/store";
import { PersistGate } from "redux-persist/integration/react";

function App() {
  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistore}>
        <BrowserRouter>
          <Myrouter></Myrouter>
        </BrowserRouter>
      </PersistGate>
    </Provider>
  );
}

export default App;
