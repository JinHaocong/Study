/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 14:40:07
 * @LastEditTime: 2022-09-11 22:35:29
 */
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function Redirect({ to }) {
  const navigate = useNavigate();
  useEffect(() => {
    navigate(to, { replace: true });
  });

  return null;
}
