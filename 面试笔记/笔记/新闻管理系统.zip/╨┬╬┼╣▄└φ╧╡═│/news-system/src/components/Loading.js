import React from "react";
import { Spin } from "antd";
import style from "./css/index.module.css";

export default function Loading() {
  return (
    <div className={style.loading}>
      <Spin size="large" className={style.loading} />
    </div>
  );
}
