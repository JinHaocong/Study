const LoadingReducer = (preState = { isLoading: false }, actions) => {
  const newState = { ...preState };
  switch (actions.type) {
    case "OPENLOADING":
      newState.isLoading = true;
      return newState;
    case "CLOSELOADING":
      newState.isLoading = false;
      return newState;
    default:
      return preState;
  }
};

export default LoadingReducer;
