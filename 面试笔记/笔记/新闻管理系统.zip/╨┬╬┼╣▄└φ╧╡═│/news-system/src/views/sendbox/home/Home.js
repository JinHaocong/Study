/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 15:15:31
 * @LastEditTime: 2022-09-16 13:43:04
 */
import { Avatar, Card, Col, Drawer, List, Row, Tag } from "antd";
import {
  EditOutlined,
  EllipsisOutlined,
  SettingOutlined,
  AppstoreOutlined,
} from "@ant-design/icons";
import React, { useEffect, useRef, useState } from "react";
import { NavLink } from "react-router-dom";
import Request from "../../../request";
import Meta from "antd/lib/card/Meta";
import * as Echarts from "echarts";
import _ from "lodash";
export default function Home() {
  const [viewList, setViewList] = useState([]);
  const [starList, setStarList] = useState([]);
  const [pieChart, setPieChart] = useState(null);
  const [allList, setAllList] = useState([]);
  const [open, setOpen] = useState(false);
  const barRef = useRef();
  const pieRef = useRef();

  const {
    username,
    region,
    role: { roleName },
  } = JSON.parse(localStorage.getItem("token"));
  useEffect(() => {
    Request({
      method: "get",
      url: "/news?publishState=2&_expand=category&_sort=view&_order=desc&_limit=8",
    }).then((res) => {
      setViewList(res);
    });

    Request({
      method: "get",
      url: "/news?publishState=2&_expand=category&_sort=star&_order=desc&_limit=8",
    }).then((res) => {
      setStarList(res);
    });

    Request({
      method: "get",
      url: "/news?publishState=2&_expand=category",
    }).then((res) => {
      setAllList(res);
      renderBar(_.groupBy(res, (item) => item.category.title));
    });

    return () => {
      window.onresize = null;
    };
  }, []);

  const renderBar = (obj) => {
    // 基于准备好的dom，初始化echarts实例
    var myChart = Echarts.init(barRef.current);

    // 指定图表的配置项和数据
    var option = {
      title: {
        text: "新闻分类图示",
      },
      tooltip: {},
      legend: {
        data: ["数量"],
      },
      xAxis: {
        data: Object.keys(obj),
        axisLabel: {
          // rotate: "45",
        },
      },
      yAxis: {
        minInterval: 1,
      },
      series: [
        {
          name: "数量",
          type: "bar",
          data: Object.values(obj).map((item) => item.length),
        },
      ],
    };

    // 使用刚指定的配置项和数据显示图表。
    myChart.setOption(option);

    window.onresize = () => {
      myChart.resize();
    };
  };
  const renderPie = () => {
    var currentList = allList.filter((item) => item.author === username);
    const pieList = _.groupBy(currentList, (item) => item.category.title);
    var list = [];
    for (var key in pieList) {
      list.push({
        name: key,
        value: pieList[key].length,
      });
    }

    if (!pieChart) {
      var myChart = Echarts.init(pieRef.current);
      setPieChart(myChart);
    } else {
      myChart = pieChart;
    }
    var option = {
      title: {
        text: `当前用户 ${username} 的新闻`,
        subtext: "分类图示",
        left: "center",
      },
      tooltip: {
        trigger: "item",
      },
      legend: {
        orient: "vertical",
        left: "left",
      },
      series: [
        {
          name: "Access From",
          type: "pie",
          radius: "50%",
          data: list,
          emphasis: {
            itemStyle: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: "rgba(0, 0, 0, 0.5)",
            },
          },
        },
      ],
    };

    // 使用刚指定的配置项和数据显示图表。
    myChart.setOption(option);

    window.onresize = () => {
      myChart.resize();
    };
  };

  const showDrawer = async () => {
    await setOpen(true);
    renderPie();
  };

  const onClose = () => {
    setOpen(false);
  };

  return (
    <div className="site-card-wrapper">
      <Row gutter={16}>
        <Col span={8}>
          <Card
            hoverable
            title="用户最常浏览"
            bordered={true}
            style={{
              boxShadow: "1px 1px 20px gray",
              height: "100%",
              overflow: "auto",
            }}
          >
            <List
              dataSource={viewList}
              renderItem={(item) => (
                <List.Item>
                  <NavLink to={`/news-manage/preview/${item.id}`}>
                    {item.title}
                  </NavLink>
                  <Tag
                    icon={<AppstoreOutlined />}
                    color="cyan"
                    style={{
                      margin: "0 10px",
                      float: "right",
                    }}
                  >
                    {item.category.title}
                  </Tag>
                </List.Item>
              )}
            />
          </Card>
        </Col>
        <Col span={8}>
          <Card
            hoverable
            title="用户点赞最多"
            bordered={true}
            style={{
              boxShadow: "1px 1px 20px gray",
              height: "100%",
              overflow: "auto",
            }}
          >
            <List
              dataSource={starList}
              renderItem={(item) => (
                <List.Item>
                  <NavLink to={`/news-manage/preview/${item.id}`}>
                    {item.title}
                  </NavLink>
                  <Tag
                    icon={<AppstoreOutlined />}
                    color="cyan"
                    style={{ margin: "0 10px", float: "right" }}
                  >
                    {item.category.title}
                  </Tag>
                </List.Item>
              )}
            />
          </Card>
        </Col>
        <Col span={8}>
          <Card
            style={{ boxShadow: "1px 1px 20px gray" }}
            cover={
              <img
                style={{ height: "350px" }}
                alt="example"
                src="https://joeschmoe.io/api/v1/random"
              />
            }
            actions={[
              <SettingOutlined
                key="setting"
                onClick={() => {
                  showDrawer();
                }}
              />,
              <EditOutlined key="edit" />,
              <EllipsisOutlined key="ellipsis" />,
            ]}
          >
            <Meta
              avatar={<Avatar src="https://joeschmoe.io/api/v1/random" />}
              title={username}
              description={
                <div>
                  <b>{region ? region : "全球"}</b>
                  <span style={{ margin: "0 10px" }}>
                    <Tag color="magenta">{roleName}</Tag>
                  </span>
                </div>
              }
            />
          </Card>
        </Col>
      </Row>

      <Drawer
        title="个人新闻"
        placement="right"
        onClose={onClose}
        open={open}
        width="600px"
      >
        <div
          ref={pieRef}
          style={{
            width: "100%",
            height: "400px",
            marginTop: "30px",
            boxShadow: "1px 1px 20px gray",
            paddingLeft: "20px",
            paddingTop: "20px",
          }}
        ></div>
      </Drawer>

      <div
        ref={barRef}
        style={{
          width: "100%",
          height: "400px",
          marginTop: "30px",
          boxShadow: "1px 1px 20px gray",
          paddingTop: "20px",
          paddingLeft: "20px",
        }}
      ></div>
    </div>
  );
}
