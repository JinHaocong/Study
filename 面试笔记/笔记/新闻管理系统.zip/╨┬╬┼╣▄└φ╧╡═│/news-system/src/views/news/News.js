import React, { useEffect, useState } from "react";
import Request from "../../request/index";
import { PageHeader, Card, Col, Row, List, Tag } from "antd";
import { AppstoreOutlined } from "@ant-design/icons";
import _ from "lodash";
import { NavLink } from "react-router-dom";

export default function News() {
  const [list, setList] = useState([]);
  useEffect(() => {
    Request({
      method: "get",
      url: "/news?publishState=2&_expand=category",
    }).then((res) => {
      setList(Object.entries(_.groupBy(res, (item) => item.category.title)));
    });
  }, []);

  return (
    <div style={{ width: "95%", margin: "0 auto" }}>
      <PageHeader
        className="site-page-header"
        onBack={() => null}
        title="新闻"
        subTitle="This is a subtitle"
      />
      <div className="site-card-wrapper">
        <Row gutter={[20, 20]}>
          {list.map((item) => {
            return (
              <Col span={8} key={item[0]}>
                <Card
                  title={item[0]}
                  bordered={false}
                //   hoverable={true}
                  style={{ height: "400px", boxShadow: "1px 1px 40px gray" }}
                >
                  <List
                    size="small"
                    pagination={{
                      pageSize: 3,
                    }}
                    dataSource={item[1]}
                    renderItem={(data) => (
                      <List.Item>
                        <NavLink to={`/detail/${data.id}`}>
                          {data.title}
                        </NavLink>
                        <Tag
                          icon={<AppstoreOutlined />}
                          color="cyan"
                          style={{
                            margin: "0 10px",
                            float: "right",
                          }}
                        >
                          {data.category.title}
                        </Tag>
                      </List.Item>
                    )}
                  />
                </Card>
              </Col>
            );
          })}
        </Row>
      </div>
    </div>
  );
}
