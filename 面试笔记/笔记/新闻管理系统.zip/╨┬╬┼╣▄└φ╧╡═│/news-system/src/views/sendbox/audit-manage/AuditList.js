/*
 * @Author: Jin Haocong
 * @Date: 2022-09-14 02:04:35
 * @LastEditTime: 2022-09-15 21:01:39
 */
import React, { useCallback, useEffect, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { Button, message, Popover, Table, Tag, notification } from "antd";
import {
  EnterOutlined,
  UserOutlined,
  GlobalOutlined,
  EditOutlined,
  AppstoreOutlined,
} from "@ant-design/icons";
import Request from "../../../request/index";

export default function AuditList() {
  const { username } = JSON.parse(localStorage.getItem("token"));
  const [auditList, setAuditList] = useState([]);
  const navigate = useNavigate();

  const getAuditList = useCallback(() => {
    Request({
      method: "get",
      url: `/news?author=${username}&auditState_ne=0&publishState_lte=1&_expand=category`,
    }).then((res) => {
      setAuditList(res);
    });
  }, [username]);

  const handleRevert = (item) => {
    Request({
      method: "patch",
      url: `/news/${item.id}`,
      data: {
        auditState: 0,
      },
    }).then(() => {
      getAuditList();
      message.success("撤销成功");
      notification.info({
        message: "通知",
        description: "您可以到草稿箱中查看新闻",
        placement: "bottomRight",
      });
    });
  };

  const handleEdit = (item) => {
    navigate(`/news-manage/update/${item.id}`);
  };

  const handlePublish = (item) => {
    Request({
      method: "patch",
      url: `/news/${item.id}`,
      data: {
        publishState: 2,
        publishTime: Date.now(),
      },
    }).then(() => {
      getAuditList();
      message.success("发布成功");
      notification.info({
        message: "通知",
        description: "您可以到【发布管理/已经发布】中查看新闻",
        placement: "bottomRight",
      });
    });
  };
  const columns = [
    {
      title: "新闻标题",
      dataIndex: "title",
      key: "title",
      align: "center",
      render: (title, item) => (
        <NavLink to={`/news-manage/preview/${item.id}`}>{title}</NavLink>
      ),
    },
    {
      title: "作者",
      dataIndex: "author",
      key: "author",
      align: "center",
      render: (author) => {
        return (
          <Tag
            color="purple"
            icon={<UserOutlined />}
            style={{ fontSize: "15px" }}
          >
            {author}
          </Tag>
        );
      },
    },
    {
      title: "新闻分类",
      dataIndex: "category",
      key: "category",
      align: "center",
      render: (category) => (
        <Tag
          icon={<AppstoreOutlined />}
          color="geekblue"
          style={{ fontSize: "15px" }}
        >
          {category.title}
        </Tag>
      ),
    },
    {
      title: "审核状态",
      dataIndex: "auditState",
      key: "auditState",
      align: "center",
      render: (auditState) => {
        const colorList = ["magenta", "orange", "green", "red"];
        const auditListMap = ["草稿箱", "审核中", "已通过", "未通过"];
        return (
          <Tag color={colorList[auditState]} style={{ fontSize: "15px" }}>
            {auditListMap[auditState]}
          </Tag>
        );
      },
    },
    {
      title: "操作",
      key: "title",
      align: "center",
      render: (item) => (
        <div>
          {item.auditState === 2 && (
            <Popover content="发布" trigger="hover" placement="bottom">
              <Button
                type="primary"
                shape="circle"
                size="large"
                icon={<GlobalOutlined />}
                style={{ background: "#00FF00", border: "0" }}
                onClick={() => {
                  handlePublish(item);
                }}
              ></Button>
            </Popover>
          )}
          {item.auditState === 1 && (
            <Popover content="撤销" trigger="hover" placement="bottom">
              <Button
                type="primary"
                shape="circle"
                size="large"
                icon={<EnterOutlined />}
                style={{ background: "orange", border: "0" }}
                onClick={() => {
                  handleRevert(item);
                }}
              ></Button>
            </Popover>
          )}
          {item.auditState === 3 && (
            <Popover content="编辑" trigger="hover" placement="bottom">
              <Button
                type="primary"
                shape="circle"
                size="large"
                icon={<EditOutlined />}
                style={{ background: "skyblue", border: "0" }}
                onClick={() => {
                  handleEdit(item);
                }}
              ></Button>
            </Popover>
          )}
        </div>
      ),
    },
  ];
  useEffect(() => {
    getAuditList();
  }, [getAuditList]);

  return (
    <Table
      columns={columns}
      dataSource={auditList}
      rowKey={(item) => item.id}
      pagination={{
        pageSize: "5",
      }}
    />
  );
}
