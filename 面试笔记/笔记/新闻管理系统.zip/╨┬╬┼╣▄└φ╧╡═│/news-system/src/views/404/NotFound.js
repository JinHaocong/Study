/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 14:51:47
 * @LastEditTime: 2022-09-11 14:54:29
 */
import React from "react";

export default function NotFound() {
  return <div>NotFound</div>;
}
