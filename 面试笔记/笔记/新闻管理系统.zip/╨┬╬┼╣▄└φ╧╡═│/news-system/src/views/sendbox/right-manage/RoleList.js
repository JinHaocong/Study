/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 15:23:38
 * @LastEditTime: 2022-09-15 14:24:52
 */
import { Table, Popover, Button, Modal, Tree, message } from "antd";
import {
  DeleteOutlined,
  UnorderedListOutlined,
  ExclamationCircleOutlined,
} from "@ant-design/icons";
import Request from "../../../request";
import React, { useCallback, useEffect, useState } from "react";
const { confirm } = Modal;

export default function RoleList() {
  const [roleList, setRoleList] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [rightList, setRightList] = useState([]);
  const [currentRights, setCurrentRights] = useState([]);
  const [currentId, setCurrentId] = useState(0);
  const columns = [
    {
      title: "ID",
      dataIndex: "id",
      align: "center",
      key: "id",
      render: (id) => {
        return <b>{id}</b>;
      },
    },
    {
      title: "角色名称",
      dataIndex: "roleName",
      align: "center",
      key: "roleName",
    },
    {
      title: "操作",
      align: "center",
      render: (item) => {
        return (
          <div>
            <Popover content="删除" trigger="hover" placement="bottom">
              <Button
                size="large"
                shape="circle"
                icon={<DeleteOutlined />}
                danger
                style={{ margin: "0 10px" }}
                onClick={() => {
                  showConfirm(item);
                }}
              />
            </Popover>
            <Popover content="编辑" trigger="hover" placement="bottom">
              <Button
                size="large"
                shape="circle"
                icon={<UnorderedListOutlined />}
                type="primary"
                style={{ margin: "0 10px" }}
                onClick={() => {
                  setIsModalOpen(true);
                  setCurrentRights(item.rights);
                  setCurrentId(item.id);
                }}
              />
            </Popover>
          </div>
        );
      },
    },
  ];

  const deleteMethod = (item) => {
    Request({
      url: `/roles/${item.id}`,
      method: "delete",
    })
      .then(() => {
        getRoleList();
        message.success("删除成功");
      })
      .catch(() => {
        message.error("删除失败");
      });
  };

  const showConfirm = (item) => {
    confirm({
      title: "确定要删除吗?",
      icon: <ExclamationCircleOutlined />,
      content: "该操作不可撤销",

      onOk() {
        deleteMethod(item);
      },

      onCancel() {},
    });
  };

  const handleOk = () => {
    setIsModalOpen(false);
    Request({
      url: `/roles/${currentId}`,
      method: "patch",
      data: {
        rights: currentRights,
      },
    })
      .then(() => {
        getRoleList();
        message.success("更新成功");
      })
      .catch(() => {
        message.error("更新失败");
      });
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  const onCheck = (item, info) => {
    setCurrentRights(item.checked);
  };

  const getRoleList = useCallback(() => {
    Request({
      url: "/roles",
      method: "get",
    }).then((res) => {
      setRoleList(res);
    });

    Request({
      url: "/rights?_embed=children",
      method: "get",
    }).then((res) => {
      setRightList(res);
    });
  }, []);

  useEffect(() => {
    getRoleList();
  }, [getRoleList]);

  return (
    <div>
      <Table
        dataSource={roleList}
        columns={columns}
        rowKey={(item) => item.id}
      ></Table>

      <Modal
        title="权限列表"
        open={isModalOpen}
        onOk={handleOk}
        onCancel={handleCancel}
      >
        <Tree
          checkable
          defaultExpandedKeys={currentRights}
          checkedKeys={currentRights}
          // onSelect={onSelect}
          treeData={rightList}
          fieldNames={{ title: "label" }}
          onCheck={onCheck}
          checkStrictly={true}
        />
      </Modal>
    </div>
  );
}
