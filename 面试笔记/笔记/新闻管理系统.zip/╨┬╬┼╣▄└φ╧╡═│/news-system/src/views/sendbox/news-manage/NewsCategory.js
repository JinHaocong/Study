/*
 * @Author: Jin Haocong
 * @Date: 2022-09-14 02:04:04
 * @LastEditTime: 2022-09-16 11:07:38
 */
import { Button, Form, Input, message, Popover, Table, Tag } from "antd";
import React, { useContext, useEffect, useRef, useState } from "react";
import {
  AppstoreOutlined,
  DeleteOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import Request from "../../../request";
import "./NewsCategory.css";
const EditableContext = React.createContext(null);

export default function NewsCategory() {
  const [categoryList, setCategoryList] = useState([]);

  const getCategoryList = () => {
    Request({
      method: "get",
      url: "/categories",
    }).then((res) => {
      setCategoryList(res);
    });
  };

  useEffect(() => {
    getCategoryList();
  }, []);

  const handleSave = (record) => {
    Request({
      method: "patch",
      url: `/categories/${record.id}`,
      data: {
        id: record.id,
        title: record.title,
        value: record.value,
      },
    }).then(() => {
      getCategoryList();
      message.success("保存成功");
    });
  };

  const handleDelete = (item) => {
    Request({
      method: "delete",
      url: `/categories/${item.id}`,
    }).then(() => {
      getCategoryList();
      message.success("删除成功");
    });
  };

  const columns = [
    {
      title: "ID",
      dataIndex: "id",
      key: "id",
      align: "center",
      render: (id) => <b>{id}</b>,
    },
    {
      title: "新闻种类",
      dataIndex: "title",
      key: "title",
      align: "center",
      render: (title) => (
        <Tag
          icon={<AppstoreOutlined />}
          color="cyan"
          style={{ fontSize: "15px" }}
        >
          {title}
        </Tag>
      ),
      onCell: (record) => ({
        record,
        editable: true,
        dataIndex: "title",
        title: "新闻种类",
        handleSave,
      }),
    },
    {
      title: "操作",
      align: "center",
      render: (item) => {
        return (
          <Popover content="删除" trigger="hover" placement="bottom">
            <Button
              type="primary"
              danger
              shape="circle"
              size="large"
              style={{ margin: "0 10px" }}
              icon={<DeleteOutlined />}
              onClick={() => {
                handleDelete(item);
              }}
            ></Button>
          </Popover>
        );
      },
    },
  ];

  const EditableRow = ({ index, ...props }) => {
    const [form] = Form.useForm();
    return (
      <Form form={form} component={false}>
        <EditableContext.Provider value={form}>
          <tr {...props} />
        </EditableContext.Provider>
      </Form>
    );
  };

  const EditableCell = ({
    title,
    editable,
    children,
    dataIndex,
    record,
    handleSave,
    ...restProps
  }) => {
    const [editing, setEditing] = useState(false);
    const inputRef = useRef(null);
    const form = useContext(EditableContext);
    useEffect(() => {
      if (editing) {
        inputRef.current.focus();
      }
    }, [editing]);

    const toggleEdit = () => {
      setEditing(!editing);
      form.setFieldsValue({
        [dataIndex]: record[dataIndex],
      });
    };

    const save = async () => {
      try {
        const values = await form.validateFields();
        toggleEdit();
        handleSave({ ...record, ...values });
      } catch (errInfo) {
        console.log("Save failed:", errInfo);
      }
    };
    let childNode = children;

    if (editable) {
      childNode = editing ? (
        <Form.Item
          style={{
            margin: 0,
          }}
          name={dataIndex}
          rules={[
            {
              required: true,
              message: `${title} is required.`,
            },
          ]}
        >
          <Input
            ref={inputRef}
            onPressEnter={save}
            onBlur={save}
            style={{ width: "300px" }}
          />
        </Form.Item>
      ) : (
        <div
          className="editable-cell-value-wrap"
          style={{
            paddingRight: 24,
          }}
          onClick={toggleEdit}
        >
          {children}
        </div>
      );
    }

    return <td {...restProps}>{childNode}</td>;
  };

  const handleAdd = () => {
    Request({
      method: "post",
      url: "/categories",
      data: {
        title: "请输入新闻种类",
        value: "请输入新闻种类",
      },
    }).then(() => {
      message.success("添加成功");
      getCategoryList();
    });
  };
  return (
    <div>
      <Button
        icon={<PlusOutlined />}
        type="primary"
        size="large"
        style={{ marginBottom: "24px", background: "#00DD99", border: "0" }}
        shape="round"
        onClick={() => {
          handleAdd();
        }}
      >
        添加种类
      </Button>
      <Table
        components={{
          body: {
            row: EditableRow,
            cell: EditableCell,
          },
        }}
        columns={columns}
        dataSource={categoryList}
        rowKey={(item) => item.id}
        pagination={{
          pageSize: "5",
        }}
      />
    </div>
  );
}
