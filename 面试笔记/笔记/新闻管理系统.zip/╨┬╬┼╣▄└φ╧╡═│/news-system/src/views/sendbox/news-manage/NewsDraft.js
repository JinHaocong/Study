/*
 * @Author: Jin Haocong
 * @Date: 2022-09-14 02:03:52
 * @LastEditTime: 2022-09-15 22:58:21
 */
import {
  Button,
  message,
  Popover,
  Table,
  Modal,
  Tag,
  notification,
} from "antd";
import React, { useCallback, useEffect, useState } from "react";
import {
  DeleteOutlined,
  EditOutlined,
  ExclamationCircleOutlined,
  UploadOutlined,
  UserOutlined,
  AppstoreOutlined,
} from "@ant-design/icons";
import Request from "../../../request";
import { NavLink, useNavigate } from "react-router-dom";
const { confirm } = Modal;

export default function NewsDraft() {
  const { username } = JSON.parse(localStorage.getItem("token"));
  const [draftList, setDraftList] = useState([]);
  const navigate = useNavigate();

  const getDraftList = useCallback(() => {
    Request({
      method: "get",
      url: `/news?author=${username}&auditState=0&_expand=category`,
    }).then((res) => {
      setDraftList(res);
    });
  }, [username]);

  useEffect(() => {
    getDraftList();
  }, [getDraftList]);

  const deleteMethod = (item) => {
    Request({
      method: "delete",
      url: `/news/${item.id}`,
    }).then(() => {
      getDraftList();
      message.success("删除成功");
    });
  };

  const showConfirm = (item) => {
    confirm({
      title: "确定要删除吗?",
      icon: <ExclamationCircleOutlined />,
      content: "该操作不可撤销",

      onOk() {
        deleteMethod(item);
      },

      onCancel() {},
    });
  };

  const handleCheck = (id) => {
    Request({
      url: `/news/${id}`,
      method: "patch",
      data: {
        auditState: 1,
      },
    }).then(() => {
      message.success("提交成功");
      navigate("/audit-manage/list");
      notification.info({
        message: "通知",
        description: "您可以到审核列表中查看新闻",
        placement: "bottomRight",
      });
    });
  };

  const columns = [
    {
      title: "ID",
      align: "center",
      dataIndex: "id",
      key: "id",
      render: (id) => <b key={id}>{id}</b>,
    },
    {
      title: "新闻标题",
      align: "center",
      dataIndex: "title",
      key: "title",
      render: (title, item) => {
        return (
          <NavLink to={`/news-manage/preview/${item.id}`}>{title}</NavLink>
        );
      },
    },
    {
      title: "作者",
      align: "center",
      dataIndex: "author",
      key: "address",
      render: (author) => {
        return (
          <Tag
            color="purple"
            icon={<UserOutlined />}
            style={{ fontSize: "15px" }}
          >
            {author}
          </Tag>
        );
      },
    },
    {
      title: "新闻分类",
      align: "center",
      dataIndex: "category",
      key: "category",
      render: (category) => {
        return (
          <Tag
            icon={<AppstoreOutlined />}
            color="geekblue"
            style={{ fontSize: "15px" }}
          >
            {category.title}
          </Tag>
        );
      },
    },
    {
      title: "操作",
      align: "center",
      render: (item) => {
        return (
          <div>
            <Popover content="删除" trigger="hover" placement="bottom">
              <Button
                size="large"
                shape="circle"
                icon={<DeleteOutlined />}
                danger
                style={{ margin: "0 10px" }}
                onClick={() => {
                  showConfirm(item);
                }}
              ></Button>
            </Popover>
            <Popover content="编辑" trigger="hover" placement="bottom">
              <Button
                size="large"
                shape="circle"
                icon={<EditOutlined />}
                type="primary"
                style={{ margin: "0 10px" }}
                onClick={() => {
                  navigate(`/news-manage/update/${item.id}`);
                }}
              ></Button>
            </Popover>
            <Popover content="提交审核" trigger="hover" placement="bottom">
              <Button
                size="large"
                shape="circle"
                icon={<UploadOutlined />}
                type="primary"
                style={{ margin: "0 10px", background: "#00FF00", border: "0" }}
                onClick={() => {
                  handleCheck(item.id);
                }}
              ></Button>
            </Popover>
          </div>
        );
      },
    },
  ];

  return (
    <Table
      columns={columns}
      dataSource={draftList}
      rowKey={(item) => item.id}
      pagination={{ pageSize: "5" }}
    />
  );
}
