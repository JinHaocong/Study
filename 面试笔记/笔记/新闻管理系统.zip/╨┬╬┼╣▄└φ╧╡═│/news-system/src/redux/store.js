/*
 * @Author: Jin Haocong
 * @Date: 2022-09-15 23:38:18
 * @LastEditTime: 2022-09-16 09:04:31
 */

import { combineReducers, configureStore } from "@reduxjs/toolkit";
import SidemenuReducer from "./reducers/SidemenuReducer";
import LoadingReducer from "./reducers/LoadingReducer";
import { persistStore, persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";

const persistConfig = {
  key: "root",
  storage,
  whitelist: ["SidemenuReducer"],
  blacklist: ["LoadingReducer"],
};

const reducer = combineReducers({
  SidemenuReducer,
  LoadingReducer,
});

const persistedReducer = persistReducer(persistConfig, reducer);

let store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) => [
    ...getDefaultMiddleware({ serializableCheck: false }),
  ],
});

let persistore = persistStore(store);

export { store, persistore };

/* 
store.dispatch

store.subscribe
*/
