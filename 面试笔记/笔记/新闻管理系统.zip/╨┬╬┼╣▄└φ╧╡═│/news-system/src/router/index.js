/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 14:36:53
 * @LastEditTime: 2022-09-16 13:02:18
 */

import { useRoutes } from "react-router-dom";
import NewsSendBox from "../views/sendbox/NewsSendBox";
import Hastoken from "../components/Hastoken";
import Lazyload from "../components/Lazyload";

export default function Myrouter() {
  const routes = useRoutes([
    {
      path: "/login",
      element: Lazyload("login/Login"),
    },
    {
      path: "/news",
      element: Lazyload("news/News"),
    },
    {
      path: "/detail/:id",
      element: Lazyload("news/Detail"),
    },
    {
      path: "*",
      element: (
        <Hastoken>
          <NewsSendBox></NewsSendBox>
        </Hastoken>
      ),
      // children: [
      //   {
      //     path: "/",
      //     element: <Redirect to="/home"></Redirect>,
      //   },
      //   {
      //     path: "/home",
      //     element: Lazyload("sendbox/home/Home"),
      //   },
      //   {
      //     path: "/user-manage/list",
      //     element: Lazyload("sendbox/user-manage/UserList"),
      //   },
      //   {
      //     path: "/right-manage/role/list",
      //     element: Lazyload("sendbox/right-manage/RoleList"),
      //   },
      //   {
      //     path: "/right-manage/right/list",
      //     element: Lazyload("sendbox/right-manage/RightList"),
      //   },
      //   {
      //     path: "/notfound",
      //     element: Lazyload("404/NotFound"),
      //   },
      //   {
      //     path: "*",
      //     element: <Redirect to="/notfound"></Redirect>,
      //   },
      // ],
    },
  ]);
  return routes;
}
