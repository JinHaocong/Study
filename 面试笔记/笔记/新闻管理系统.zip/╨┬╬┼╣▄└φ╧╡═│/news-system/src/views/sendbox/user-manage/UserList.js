/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 15:22:32
 * @LastEditTime: 2022-09-15 14:20:45
 */
import React, { useState, useEffect, useRef, useCallback } from "react";
import { Button, Table, Modal, Popover, Switch, Tag, message } from "antd";
import {
  DeleteOutlined,
  ExclamationCircleOutlined,
  PlusOutlined,
  EditOutlined,
} from "@ant-design/icons";
import Userform from "../../../components/user-manage/Userform";
import Request from "../../../request";
const { confirm } = Modal;

export default function UserList() {
  const [dataSource, setDataSource] = useState([]);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isUpdateOpen, setIsUpdateOpen] = useState(false);
  const [regionList, setRegionList] = useState([]);
  const [roleList, setRoleList] = useState([]);
  const [isUpdateDisabled, setIsUpdateDisabled] = useState(false);
  const [current, setCurrent] = useState({});
  const [formType, setFormType] = useState("add");
  const addFormRef = useRef(null);
  const updateFormRef = useRef(null);
  const { roleId, region, username } = JSON.parse(
    localStorage.getItem("token")
  );
  const getDataList = useCallback(() => {
    const roleMap = {
      1: "superadmin",
      2: "admin",
      3: "editor",
    };
    //dataSource
    Request({
      url: "/users?_expand=role",
      method: "get",
    }).then((res) => {
      setDataSource(
        roleMap[roleId] === "superadmin"
          ? res
          : [
              ...res.filter((item) => item.username === username),
              ...res.filter(
                (item) =>
                  item.region === region && roleMap[item.roleId] === "editor"
              ),
            ]
      );
    });

    //region
    Request({
      url: "/regions",
      method: "get",
    }).then((res) => {
      const list = res;
      setRegionList(list);
    });

    //role
    Request({
      url: "/roles",
      method: "get",
    }).then((res) => {
      setRoleList(res);
    });
  }, [roleId, region, username]);

  useEffect(() => {
    getDataList();
  }, [getDataList]);

  const columns = [
    {
      title: "区域",
      dataIndex: "region",
      align: "center",
      key: "region",
      filters: [
        ...regionList.map((item) => {
          return {
            text: item.title,
            value: item.value,
          };
        }),
        {
          text: "全球",
          value: "全球",
        },
      ],
      onFilter: (value, item) => {
        if (value === "全球") {
          return item.region === "";
        }
        return item.region === value;
      },
      render: (region) => {
        return <b>{region === "" ? "全球" : region}</b>;
      },
    },
    {
      title: "角色名称",
      align: "center",
      dataIndex: "role",
      key: "role",
      filters: [
        ...roleList.map((item) => {
          return {
            text: item.roleName,
            value: item.roleName,
          };
        }),
      ],
      onFilter: (value, item) => {
        return item.role.roleName === value;
      },
      render: (role) => {
        return (
          <Tag style={{ fontSize: "15px" }} color="cyan">
            {role.roleName}
          </Tag>
        );
      },
    },
    {
      title: "用户名",
      align: "center",
      dataIndex: "username",
      key: "username",
    },
    {
      title: "用户状态",
      align: "center",
      dataIndex: "roleState",
      key: "roleState",
      render: (roleState, item) => {
        return (
          <Switch
            checked={roleState}
            disabled={item.default}
            onChange={() => {
              switchMethod(item);
            }}
          ></Switch>
        );
      },
    },
    {
      title: "操作",
      align: "center",
      render: (item) => {
        return (
          <div>
            <Popover content="删除" trigger="hover" placement="bottom">
              <Button
                disabled={item.default}
                shape="circle"
                icon={<DeleteOutlined />}
                danger
                size="large"
                style={{ margin: "0 10px" }}
                onClick={() => {
                  showConfirm(item);
                }}
              />
            </Popover>
            <Popover content="编辑" trigger="hover" placement="bottom">
              <Button
                disabled={item.default}
                shape="circle"
                size="large"
                icon={<EditOutlined />}
                type="primary"
                style={{ margin: "0 10px" }}
                onClick={() => {
                  updateForm(item);
                }}
              />
            </Popover>
          </div>
        );
      },
    },
  ];

  const updateForm = async (item) => {
    setFormType("update");
    setCurrent(item);
    await setIsUpdateOpen(true);
    if (item.roleId === 1) {
      setIsUpdateDisabled(true);
    } else {
      setIsUpdateDisabled(false);
    }
    updateFormRef.current.setFieldsValue(item);
  };

  const deleteMethod = (item) => {
    Request({
      url: `/users/${item.id}`,
      method: "delete",
    })
      .then(() => {
        getDataList();
        message.success("删除成功");
      })
      .catch(() => {
        message.error("删除失败");
      });
  };

  const showConfirm = (item) => {
    confirm({
      title: "确定要删除吗?",
      icon: <ExclamationCircleOutlined />,
      content: "该操作不可撤销",
      onOk() {
        deleteMethod(item);
      },

      onCancel() {},
    });
  };

  const switchMethod = (item) => {
    item.roleState = !item.roleState;
    Request({
      url: `/users/${item.id}`,
      method: "patch",
      data: {
        roleState: item.roleState,
      },
    })
      .then(() => {
        getDataList();
        message.success("切换状态成功");
      })
      .catch(() => {
        message.error("切换失败");
      });
  };

  const addFormOk = () => {
    addFormRef.current
      .validateFields()
      .then((value) => {
        setIsAddOpen(false);
        Request({
          url: "/users",
          method: "post",
          data: {
            ...value,
            roleState: true,
            default: false,
          },
        }).then(() => {
          addFormRef.current.resetFields();
          getDataList();
          message.success("添加成功");
        });
      })
      .catch((err) => console.log(err));
  };

  const updateFormOk = () => {
    updateFormRef.current.validateFields().then((value) => {
      Request({
        url: `/users/${current.id}`,
        method: "patch",
        data: value,
      })
        .then(() => {
          message.success("更新成功");
          getDataList();
        })
        .catch(() => {
          message.error("更新失败");
        });
    });
    setIsUpdateOpen(false);
  };

  const addFormCancel = () => {
    setIsAddOpen(false);
    addFormRef.current.resetFields();
  };

  const updateFormCancel = async () => {
    await setIsUpdateOpen(false);
    setIsUpdateDisabled(!isUpdateDisabled);
  };

  const addUser = () => {
    setIsAddOpen(true);
    setFormType("add");
  };

  return (
    <div>
      <Button
        style={{ marginBottom: "20px" }}
        icon={<PlusOutlined />}
        type="primary"
        shape="round"
        onClick={() => {
          addUser();
        }}
      >
        添加用户
      </Button>
      <Table
        dataSource={dataSource}
        columns={columns}
        pagination={{ pageSize: "10" }}
        rowKey={(item) => item.id}
      />
      <Modal
        open={isAddOpen}
        title="添加用户"
        okText="添加"
        cancelText="取消"
        onCancel={() => {
          addFormCancel();
        }}
        onOk={() => {
          addFormOk();
        }}
      >
        <Userform
          regionList={regionList}
          roleList={roleList}
          ref={addFormRef}
          formType={formType}
        ></Userform>
      </Modal>
      <Modal
        open={isUpdateOpen}
        title="更新用户"
        okText="更新"
        cancelText="取消"
        onCancel={() => {
          updateFormCancel();
        }}
        onOk={() => {
          updateFormOk();
        }}
      >
        <Userform
          regionList={regionList}
          roleList={roleList}
          ref={updateFormRef}
          isUpdateDisabled={isUpdateDisabled}
          formType={formType}
        ></Userform>
      </Modal>
    </div>
  );
}
