/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 14:55:11
 * @LastEditTime: 2022-09-16 08:55:46
 */
import React, { useRef, useEffect, useState } from "react";
import Topheader from "../../components/Topheader";
import Sidemenu from "../../components/Sidemenu";
import { Route, Routes } from "react-router-dom";
import "./NewsSendBox.css";
import { Layout } from "antd";
import Redirect from "../../components/Redirect";
import Lazyload from "../../components/Lazyload";
import Request from "../../request";
import { connect } from "react-redux";
import Loading from "../../components/Loading";
const { Content } = Layout;

function NewsSendBox(props) {
  // const { isLoading } = props;
  const [routeList, setRouteList] = useState([]);
  const ChidlRef = useRef(null);
  const getData = () => {
    ChidlRef.current.getMenuList();
  };
  const localRouterMap = {
    "/home": Lazyload("sendbox/home/Home"),
    "/user-manage/list": Lazyload("sendbox/user-manage/UserList"),
    "/right-manage/role/list": Lazyload("sendbox/right-manage/RoleList"),
    "/right-manage/right/list": Lazyload(
      "sendbox/right-manage/RightList",
      getData
    ),
    "/news-manage/add": Lazyload("sendbox/news-manage/NewsAdd"),
    "/news-manage/draft": Lazyload("sendbox/news-manage/NewsDraft"),
    "/news-manage/category": Lazyload("sendbox/news-manage/NewsCategory"),
    "/news-manage/preview/:id": Lazyload("sendbox/news-manage/NewsPreview"),
    "/news-manage/update/:id": Lazyload("sendbox/news-manage/NewsUpdate"),
    "/audit-manage/audit": Lazyload("sendbox/audit-manage/Audit"),
    "/audit-manage/list": Lazyload("sendbox/audit-manage/AuditList"),
    "/publish-manage/unpublished": Lazyload(
      "sendbox/publish-manage/Unpublished"
    ),
    "/publish-manage/published": Lazyload("sendbox/publish-manage/Published"),
    "/publish-manage/sunset": Lazyload("sendbox/publish-manage/Sunset"),
  };

  useEffect(() => {
    Promise.all([
      Request({ url: "/rights", method: "get" }),
      Request({ url: "/children", method: "get" }),
    ]).then((res) => {
      setRouteList([...res[0], ...res[1]]);
    });
  }, []);

  const {
    role: { rights },
  } = JSON.parse(localStorage.getItem("token"));

  const checkRoute = (item) => {
    return (
      localRouterMap[item.key] && (item.pagepermisson || item.routepermisson)
    );
  };

  const checkUserPermission = (item) => {
    return rights.includes(item.key);
  };

  return (
    <div className="box">
      <Layout>
        <Sidemenu ref={ChidlRef}></Sidemenu>
        <Layout className="site-layout">
          <Topheader></Topheader>
          <Content
            className="site-layout-background"
            style={{
              margin: "24px 16px",
              padding: 24,
              minHeight: 280,
              position: "relative",
              overflow: "auto",
            }}
          >
            {/* <Spin size="large" spinning={isLoading}> */}
            <Routes>
              {routeList.map((item) => {
                if (checkRoute(item) && checkUserPermission(item)) {
                  return (
                    <Route
                      path={item.key}
                      element={localRouterMap[item.key]}
                      key={item.key}
                    ></Route>
                  );
                }
                return null;
              })}
              <Route
                path="/"
                element={<Redirect to="/home"></Redirect>}
              ></Route>
              <Route path="/loading" element={<Loading></Loading>}></Route>

              {routeList.length > 0 && (
                <Route path="*" element={Lazyload("404/NotFound")}></Route>
              )}
            </Routes>
            {/* </Spin> */}
          </Content>
        </Layout>
      </Layout>
    </div>
  );
}

const mapStateToProps = (state) => {
  return {
    isLoading: state.LoadingReducer.isLoading,
  };
};

export default connect(mapStateToProps)(NewsSendBox);
