/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 14:25:30
 * @LastEditTime: 2022-09-11 14:33:39
 */
const { createProxyMiddleware } = require("http-proxy-middleware");
module.exports = function (app) {
  app.use(
    "/api",
    createProxyMiddleware({
      target: "https://i.maoyan.com",
      changeOrigin: true,
      // pathRewrite: {
      //     '^/api': ''
      // }
    })
  );
};
