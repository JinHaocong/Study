/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 15:14:03
 * @LastEditTime: 2022-09-16 11:37:01
 */
import React from "react";
import { Layout, Dropdown, Menu, Avatar } from "antd";
import {
  MenuFoldOutlined,
  MenuUnfoldOutlined,
  UserOutlined,
} from "@ant-design/icons";
import { useNavigate } from "react-router-dom";
import { connect } from "react-redux";
const { Header } = Layout;

function Topheader(props) {
  const { isCollapsed } = props;
  const navigate = useNavigate();
  const users = JSON.parse(localStorage.getItem("token"));

  const changeCollapsed = () => {
    props.changeCollapsed();
    // store.dispatch({
    //   type: "CHANGECOLLAPSED",
    //   value: 121311,
    // });
  };

  const menu = (
    <Menu
      items={[
        {
          key: "1",
          label: `${users.role.roleName}`,
        },
        {
          key: "2",
          danger: true,
          label: "退出登录",
          onClick: () => {
            localStorage.removeItem("token");
            navigate("/login");
          },
        },
      ]}
    ></Menu>
  );

  return (
    <Header
      className="site-layout-background"
      style={{
        padding: 0,
      }}
    >
      {isCollapsed ? (
        <MenuUnfoldOutlined
          className="trigger"
          onClick={() => {
            changeCollapsed();
          }}
        ></MenuUnfoldOutlined>
      ) : (
        <MenuFoldOutlined
          className="trigger"
          onClick={() => {
            changeCollapsed();
          }}
        ></MenuFoldOutlined>
      )}
      <div style={{ float: "right", marginRight: "30px" }}>
        <span style={{ marginRight: "20px" }}>
          欢迎
          <span
            style={{ color: "skyblue", fontSize: "20px", margin: "0 10px" }}
          >
            {users.username}
          </span>
          回来
        </span>
        <Dropdown overlay={menu}>
          <Avatar
            size="large"
            icon={<UserOutlined />}
            src="https://joeschmoe.io/api/v1/random"
          />
        </Dropdown>
      </div>
    </Header>
  );
}

const mapStateToProps = (state) => {
  return {
    isCollapsed: state.SidemenuReducer.isCollapased,
  };
};

const mapDispatchToProps = {
  changeCollapsed() {
    return {
      type: "CHANGECOLLAPSED",
      value: 111,
    };
  },
};

export default connect(mapStateToProps, mapDispatchToProps)(Topheader);
