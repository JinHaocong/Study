/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 15:22:14
 * @LastEditTime: 2022-09-13 01:27:05
 */
import React from "react";

export default function List() {
  return <div>List</div>;
}
