<!--
 * @Author: Jin Haocong
 * @Date: 2022-08-21 16:48:26
 * @LastEditTime: 2022-08-21 16:48:31
-->
<template>
  <div>团购订单</div>
</template>

<script>
export default {
  name: "GroupOrder",
};
</script>

<style>
</style>