/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 15:24:28
 * @LastEditTime: 2022-09-11 15:24:30
 */
import React from "react";

export default function RoleList() {
  return <div>RoleList</div>;
}
