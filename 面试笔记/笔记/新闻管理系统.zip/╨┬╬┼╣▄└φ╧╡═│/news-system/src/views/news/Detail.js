/*
 * @Author: Jin Haocong
 * @Date: 2022-09-14 22:31:39
 * @LastEditTime: 2022-09-16 14:57:00
 */
import { Descriptions, PageHeader, Tag } from "antd";
import { UserOutlined, HeartTwoTone, SmileTwoTone } from "@ant-design/icons";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import style from "./Detail.module.css";
import moment from "moment";
import Request from "../../request";

export default function NewsPreview() {
  const [newsInfo, setNewsInfo] = useState();
  const params = useParams();
  useEffect(() => {
    Request({
      method: "get",
      url: `/news/${params.id}?_expand=category&_expand=role`,
    })
      .then((res) => {
        setNewsInfo({
          ...res,
          view: res.view + 1,
        });
        return res;
      })
      .then((res) => {
        Request({
          method: "patch",
          url: `/news/${params.id}?_expand=category&_expand=role`,
          data: {
            view: res.view + 1,
          },
        });
      });
  }, [params]);

  const handleStar = () => {
    setNewsInfo({
      ...newsInfo,
      star: newsInfo.star + 1,
    });

    Request({
      method: "patch",
      url: `/news/${params.id}?_expand=category&_expand=role`,
      data: {
        star: newsInfo.star + 1,
      },
    });
  };

  return (
    <div className={style.pageheader}>
      {newsInfo && (
        <div>
          <PageHeader
            ghost={false}
            onBack={() => window.history.back()}
            title={newsInfo.title}
            subTitle={
              <div>
                {newsInfo.category.title}{" "}
                <HeartTwoTone
                  twoToneColor="#eb2f96"
                  style={{ margin: "0 5px" }}
                  onClick={() => {
                    handleStar();
                  }}
                />
              </div>
            }
          >
            <Descriptions size="small" column={3}>
              <Descriptions.Item label="创建者">
                <Tag color="purple" icon={<UserOutlined />}>
                  {newsInfo.author}
                </Tag>
              </Descriptions.Item>
              <Descriptions.Item label="发布时间">
                {newsInfo.publishTime
                  ? moment(newsInfo.publishTime).format("YYYY-MM-DD  HH:mm:ss")
                  : "-"}
              </Descriptions.Item>
              <Descriptions.Item label="区域">
                {newsInfo.region}
              </Descriptions.Item>
              <Descriptions.Item label="访问数量">
                <div>
                  {newsInfo.view}
                  <SmileTwoTone
                    twoToneColor="#52c41a"
                    style={{ margin: "0 5px" }}
                  />
                </div>
              </Descriptions.Item>
              <Descriptions.Item label="点赞数量">
                <div>
                  {newsInfo.star}
                  <HeartTwoTone
                    twoToneColor="#eb2f96"
                    style={{ margin: "0 5px" }}
                  />
                </div>
              </Descriptions.Item>
              <Descriptions.Item label="评论数量">0</Descriptions.Item>
            </Descriptions>
          </PageHeader>
          <div
            dangerouslySetInnerHTML={{ __html: newsInfo.content }}
            className={style.contentbox}
          ></div>
        </div>
      )}
    </div>
  );
}
