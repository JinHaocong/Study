/*
 * @Author: Jin Haocong
 * @Date: 2022-09-14 22:31:39
 * @LastEditTime: 2022-09-16 14:29:10
 */
import { Descriptions, PageHeader, Tag } from "antd";
import { UserOutlined, HeartTwoTone, SmileTwoTone } from "@ant-design/icons";
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Request from "../../../request";
import style from "./News.module.css";
import moment from "moment";

export default function NewsPreview() {
  const [newsInfo, setNewsInfo] = useState();
  const params = useParams();
  const colorList = ["magenta", "orange", "green", "red"];
  useEffect(() => {
    Request({
      method: "get",
      url: `/news/${params.id}?_expand=category&_expand=role`,
    }).then((res) => {
      setNewsInfo(res);
    });
  }, [params]);

  const auditState = () => {
    switch (newsInfo.auditState) {
      case 0:
        return "未审核";
      case 1:
        return "审核中";
      case 2:
        return "已通过";
      case 3:
        return "未通过";
      default:
        return "未审核";
    }
  };

  const publishState = () => {
    switch (newsInfo.publishState) {
      case 0:
        return "未发布";
      case 1:
        return "待发布";
      case 2:
        return "已上线";
      case 3:
        return "已下线";
      default:
        return "未发布";
    }
  };

  return (
    <div className={style.pageheader}>
      {newsInfo && (
        <div>
          <PageHeader
            ghost={false}
            onBack={() => window.history.back()}
            title={newsInfo.title}
            subTitle={newsInfo.category.title}
          >
            <Descriptions size="small" column={3}>
              <Descriptions.Item label="创建者">
                <Tag color="purple" icon={<UserOutlined />}>
                  {newsInfo.author}
                </Tag>
              </Descriptions.Item>
              <Descriptions.Item label="创建时间">
                {moment(newsInfo.createTime).format("YYYY-MM-DD  HH:mm:ss")}
              </Descriptions.Item>
              <Descriptions.Item label="发布时间">
                {newsInfo.publishTime
                  ? moment(newsInfo.publishTime).format("YYYY-MM-DD  HH:mm:ss")
                  : "-"}
              </Descriptions.Item>
              <Descriptions.Item label="区域">
                {newsInfo.region}
              </Descriptions.Item>
              <Descriptions.Item label="审核状态">
                <Tag color={colorList[newsInfo.auditState]}>{auditState()}</Tag>
              </Descriptions.Item>
              <Descriptions.Item label="发布状态">
                <Tag color={colorList[newsInfo.publishState]}>
                  {publishState()}
                </Tag>
              </Descriptions.Item>
              <Descriptions.Item label="访问数量">
                <div>
                  {newsInfo.view}
                  <SmileTwoTone
                    twoToneColor="#52c41a"
                    style={{ margin: "0 5px" }}
                  />
                </div>
              </Descriptions.Item>
              <Descriptions.Item label="点赞数量">
                <div>
                  {newsInfo.star}
                  <HeartTwoTone
                    twoToneColor="#eb2f96"
                    style={{ margin: "0 5px" }}
                  />
                </div>
              </Descriptions.Item>
              <Descriptions.Item label="评论数量">0</Descriptions.Item>
            </Descriptions>
          </PageHeader>
          <div
            dangerouslySetInnerHTML={{ __html: newsInfo.content }}
            className={style.contentbox}
          ></div>
        </div>
      )}
    </div>
  );
}
