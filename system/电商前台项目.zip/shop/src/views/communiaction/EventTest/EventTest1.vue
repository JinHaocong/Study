<!--
 * @Author: Jin Haocong
 * @Date: 2022-08-21 23:23:45
 * @LastEditTime: 2022-08-21 23:33:13
-->
<template>
  <div>
    <div class="main">
      <h1>EventTest1</h1>
      <span>其他内容</span>
    </div>
  </div>
</template>

<script>
export default {
  name: "EventTest1",
};
</script>

<style lang="less" scoped>
.main {
  width: 100%;
  height: 200px;
  background-color: rgb(184, 184, 184);
}
</style>