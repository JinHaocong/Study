/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 15:12:23
 * @LastEditTime: 2022-09-16 12:51:35
 */
import React, {
  useState,
  useEffect,
  useImperativeHandle,
  useCallback,
} from "react";
import { Menu, Layout } from "antd";
import {
  RadarChartOutlined,
  HomeOutlined,
  UserOutlined,
  LockOutlined,
  AppstoreOutlined,
  CheckOutlined,
  GlobalOutlined,
} from "@ant-design/icons";
import { useLocation, useNavigate } from "react-router-dom";
import "./css/Sidemenu.css";
import Request from "../request";
import { connect } from "react-redux";

const { Sider } = Layout;

const Sidemenu = React.forwardRef((props, ref) => {
  const [menuListMine, setMenuListMine] = useState([]);
  const navigaet = useNavigate();
  const items = menuListMine;
  const location = useLocation();

  const getMenuList = useCallback(() => {
    const users = JSON.parse(localStorage.getItem("token"));
    var iconList = [
      <HomeOutlined />,
      <UserOutlined />,
      <LockOutlined />,
      <AppstoreOutlined />,
      <CheckOutlined />,
      <GlobalOutlined />,
    ];
    Request({
      url: "/rights?_embed=children",
      method: "get",
    }).then((res) => {
      var list = res;
      for (var index in list) {
        list[index].icon = iconList[index];
        if (list[index].children.length !== 0) {
          for (var childrenIndex in list[index].children) {
            delete list[index].children[childrenIndex].rightId;
          }
        }
      }
      filterMenuList(list, users);
    });
  }, []);
  useEffect(() => {
    getMenuList();
  }, [getMenuList]);

  useImperativeHandle(ref, () => ({
    getMenuList,
  }));

  //过滤函数
  const filterMenuList = (menuList, users) => {
    const newList = [];
    for (var a = 0; a < menuList.length; a++) {
      for (var b = 0; b < users.role.rights.length; b++) {
        if (menuList[a].key === users.role.rights[b]) {
          newList.push(menuList[a]);
        }
      }
    }

    for (var i = 0; i < newList.length; i++) {
      if (newList[i].children && newList[i].children.length > 0) {
        for (var j = 0; j < newList[i].children.length; j++) {
          if (users.role.rights.indexOf(newList[i].children[j].key) === -1) {
            newList[i].children.splice(j, 1);
            j--;
          }
        }
      }
    }
    for (var index = 0; index < newList.length; index++) {
      if (
        newList[index].pagepermisson === undefined ||
        newList[index].pagepermisson !== 1
      ) {
        newList.splice(index, 1);
        if (index > 0) {
          index--;
        }
      }

      if (newList[index].children && newList[index].children.length === 0) {
        delete newList[index].children;
      }

      if (newList[index].children) {
        for (
          var childrenIndex2 = 0;
          childrenIndex2 < newList[index].children.length;
          childrenIndex2++
        ) {
          if (newList[index].children[childrenIndex2].pagepermisson !== 1) {
            newList[index].children.splice(childrenIndex2, 1);
            childrenIndex2--;
          }
        }
      }
    }
    setMenuListMine(newList);
  };
  return (
    <Sider trigger={null} collapsible collapsed={props.isCollapsed}>
      <div className="menu">
        <div className="logo">
          <span className="iconbox" style={{ margin: "0 30px" }}>
            <RadarChartOutlined className="icon" />
          </span>
          <span>新闻发布系统</span>
        </div>
        <div>
          <Menu
            className="menu"
            theme="dark"
            mode="inline"
            selectedKeys={[location.pathname]}
            items={items}
            onClick={(evt) => {
              navigaet(evt.key);
            }}
            defaultOpenKeys={["/" + location.pathname.split("/")[1]]}
          ></Menu>
        </div>
      </div>
    </Sider>
  );
});

const mapStateToProps = (state) => {
  return {
    isCollapsed: state.SidemenuReducer.isCollapased,
  };
};

const mapDispatchToProps = {};

export default connect(mapStateToProps, mapDispatchToProps, null, {
  forwardRef: true,
})(Sidemenu);
