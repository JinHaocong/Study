/*
 * @Author: Jin Haocong
 * @Date: 2022-09-11 14:43:55
 * @LastEditTime: 2022-09-14 01:43:38
 */
import React from "react";
import Loading from "./Loading";

export default function Lazyload(path, props) {
  const Lazycomponent = React.lazy(() => import(`../views/${path}`));
  return (
    <React.Suspense fallback={<Loading></Loading>}>
      <Lazycomponent getData={props}></Lazycomponent>
    </React.Suspense>
  );
}
