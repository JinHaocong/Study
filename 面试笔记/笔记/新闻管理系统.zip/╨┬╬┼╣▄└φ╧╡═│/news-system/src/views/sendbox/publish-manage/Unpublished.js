/*
 * @Author: Jin Haocong
 * @Date: 2022-09-14 02:04:59
 * @LastEditTime: 2022-09-15 22:55:05
 */
import React from "react";
import useGetNewsList from "../../../components/publish-manage/getNewsList";
import NewsPublish from "../../../components/publish-manage/NewsPublish";

export default function Unpublished() {
  const { newsList, handlePublish } = useGetNewsList(1);

  return (
    <div>
      <NewsPublish
        newsList={newsList}
        buttonType={1}
        handlePublish={(item) => {
          handlePublish(item);
        }}
      ></NewsPublish>
    </div>
  );
}
