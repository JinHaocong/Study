/*
 * @Author: Jin Haocong
 * @Date: 2022-09-13 13:51:00
 * @LastEditTime: 2022-09-16 08:39:22
 */
import axios from "axios";
import NProgress from "nprogress";
import "nprogress/nprogress.css";
import { store } from "../redux/store";

// const resetToken = () => {
//   const { username, password } = JSON.parse(localStorage.getItem("token"));

//   axios({
//     url: `http://localhost:8000/users/?username=${username}&password=${password}&roleState=true&_expand=role`,
//     method: "get",
//   }).then((res) => {
//     if (res.data.length > 0) {
//       localStorage.setItem("token", JSON.stringify(res.data[0]));
//     }
//   });
// };
const axiosOption = {
  baseURL: "http://localhost:8000",
  timeout: 5000,
};

const Request = axios.create(axiosOption);

Request.interceptors.request.use(
  (config) => {
    // store.dispatch({
    //   type: "OPENLOADING",
    // });
    NProgress.start();
    return config;
  },
  (err) => {
    return Promise.reject(err);
  }
);

Request.interceptors.response.use(
  (res) => {
    NProgress.done();
    store.dispatch({
      type: "CLOSELOADING",
    });

    // if (res.data.length !== 0 && localStorage.getItem("token") === null) {
    //   localStorage.setItem("token", JSON.stringify(res[0]));
    // } else {
    //   if (res.data.length !== 0) {
    //     resetToken();
    //   }
    // }
    return res.data;
  },
  (err) => {
    return Promise.reject(err);
  }
);

export default Request;
