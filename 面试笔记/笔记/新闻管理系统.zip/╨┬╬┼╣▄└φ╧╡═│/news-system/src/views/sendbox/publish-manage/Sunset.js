/*
 * @Author: Jin Haocong
 * @Date: 2022-09-14 02:05:26
 * @LastEditTime: 2022-09-15 23:03:36
 */
import React from "react";
import useGetNewsList from "../../../components/publish-manage/getNewsList";
import NewsPublish from "../../../components/publish-manage/NewsPublish";

export default function Sunset() {
  const { newsList, handleDelete, handlePublish } = useGetNewsList(3);

  return (
    <div>
      <NewsPublish
        newsList={newsList}
        buttonType={3}
        handleDelete={(item) => {
          handleDelete(item);
        }}
        handlePublish={(item) => {
          handlePublish(item);
        }}
      ></NewsPublish>
    </div>
  );
}
