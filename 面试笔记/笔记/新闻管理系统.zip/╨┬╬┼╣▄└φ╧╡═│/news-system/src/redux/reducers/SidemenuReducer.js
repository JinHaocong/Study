/*
 * @Author: Jin Haocong
 * @Date: 2022-09-15 23:43:54
 * @LastEditTime: 2022-09-16 00:25:47
 */

const SidemenuReducer = (preState = { isCollapased: false }, action) => {
  const newState = { ...preState };
  switch (action.type) {
    case "CHANGECOLLAPSED":
      newState.isCollapased = !newState.isCollapased;
      return newState;
    default:
      return preState;
  }
};

export default SidemenuReducer;
